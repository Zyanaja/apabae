// ========== Footer.jsx ==========
import React from 'react';

export const Footer = () => {
  return (
    <footer className="bg-black text-center py-6 text-sm text-gray-400">
      © 2025 Zyan to Web. Dibuat dengan 🖤 sama Coko & Kak AL
    </footer>
  );
};